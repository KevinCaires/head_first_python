"""
Módulo de setup.
"""
from setuptools import setup


setup(
    name='vsearch',
    version='1.0',
    description='Primeiro setup tools do use a cabeça python.',
    author='HF Python 2e',
    author_email='hfpy2e@gmail.com',
    url='headfirstlabs.com',
    py_modules=['vsearch'],
)
